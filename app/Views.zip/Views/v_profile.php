<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<h2>Profil Pengguna</h2>

<table class="table">
    <tr>
        <th>Username</th>
        <td><?= esc($username) ?></td>
    </tr>
    <tr>
        <th>Role</th>
        <td><?= esc($role) ?></td>
    </tr>
    <tr>
        <th>Email</th>
        <td><?= esc($email) ?></td>
    </tr>
    <tr>
        <th>Waktu Login</th>
        <td><?= esc($login_time) ?></td>
    </tr>
    <tr>
        <th>Status Login</th>
        <td><?= $isLoggedIn ? 'Logged In' : 'Logged Out' ?></td>
    </tr>
</table>

<?= $this->endSection() ?>
