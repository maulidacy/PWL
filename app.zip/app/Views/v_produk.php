<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

ini halaman produk
<?= $this->endSection() ?>