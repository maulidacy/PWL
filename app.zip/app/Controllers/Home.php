<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('v_home');
    }

    public function profile(): string
    {
        $session = session();
        $data = [
            'username' => $session->get('username'),
            'role' => $session->get('role'),
            'email' => $session->get('email'),
            'login_time' => $session->get('login_time'),
            'isLoggedIn' => $session->get('isLoggedIn'),
        ];
        return view('v_profile', $data);
    }

    public function faq(): string
    {
        return view('v_faq');
    }
}
